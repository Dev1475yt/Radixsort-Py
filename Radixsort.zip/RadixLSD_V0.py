import random
import time
LenInput = 99#int(input("Length?"))
solved = False
List = []
DigitVal = [[],[],[],[],[],[],[],[],[],[]]

def Shufill(LIST, LEN):
    for N in range(0,LEN):
        LIST.insert(N, N+1)
    random.shuffle(LIST)
    solved = False
    print(LIST,'\n')
Shufill(List, LenInput)

def GetDigit(N, D):
    if D<=len(str(N))-1:
        return int(str(N)[(len(str(N))-D)-1])
    elif D > len(str(N))-1:
        return 0

while solved != True:
    for Digit in range(3):
        for element in range(len(List)):
            DigitVal[GetDigit(List[element],Digit)].insert(len(DigitVal)-1,List[element])
        List = []
        for item in range(len(DigitVal)-1,-1,-1):
            for i in range(len(DigitVal[item])-1,-1,-1):
                List.insert(0,DigitVal[item][i])
        DigitVal = [[],[],[],[],[],[],[],[],[],[]]
    if List == sorted(List):
            solved = True
print(List)

