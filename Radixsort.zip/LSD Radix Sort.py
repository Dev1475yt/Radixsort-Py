import pygame as pg
import random
import time
steps = 0
LenInput = 99#int(input("Length?"))
solved = False
List = []
DigitVal = [[],[],[],[],[],[],[],[],[],[]]

def Shufill(LIST, LEN):
    for N in range(0,LEN):
        LIST.insert(N, N+1)
    random.shuffle(LIST)
    solved = False
    print(LIST,'\n')
Shufill(List, LenInput)

def GetDigit(N, D):
    if D<=len(str(N))-1:
        return int(str(N)[(len(str(N))-D)-1])
    elif D > len(str(N))-1:
        return 0

while solved != True:
    for Digit in range(len(str(LenInput))):
        steps = steps + 1
        for element in range(len(List)):
            DigitVal[GetDigit(List[element],Digit)].insert(len(DigitVal)-1,List[element])
            steps = steps + 1
        List = []
        for item in range(len(DigitVal)-1,-1,-1):
            for i in range(len(DigitVal[item])-1,-1,-1):
                List.insert(0,DigitVal[item][i])
                steps = steps + 1
        DigitVal = [[],[],[],[],[],[],[],[],[],[]]
    if List == sorted(List):
            solved = True
print(List)
print("Done in ",steps,"steps!")

