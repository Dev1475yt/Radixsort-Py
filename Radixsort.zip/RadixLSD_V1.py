import random
import time
LenInput = int(input("Length?"))
solved = False
List = []
DigitVal = [[],[],[],[],[],[],[],[],[],[]]
#Good ***************************************************************************
def Shufill(LIST, LEN):
    for N in range(0,LEN):
        LIST.insert(N, N+1)
    random.shuffle(LIST)
    solved = False
    print(LIST,'\n')

def GetDigit(N, D):
    if D<=len(str(N))-1:
        return int(str(N)[(len(str(N))-D)-1])
    elif D > len(str(N))-1:
        return 0

Shufill(List,LenInput)
##List = [110,105,100,55,50,45,1,2,3]

#End Good Code ******************************************************************

while solved == False:
    for Digit in range(len(str(LenInput))):
        for element in range(len(List)):
            DigitVal[GetDigit(List[element],Digit)].insert(len(DigitVal)-1,List[element])
        List = []
        for item in range(len(DigitVal)-1,-1,-1):
            for i in range(len(DigitVal[item])-1,-1,-1):
                List.insert(0,DigitVal[item][i])
        if List == sorted(List):
            break
        DigitVal = [[],[],[],[],[],[],[],[],[],[]]
    solved = True
    print(List, flush=True)

